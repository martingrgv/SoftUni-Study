﻿namespace DefiningClasses;

public enum CargoType
{
    Flammable,
    Fragile,
}