﻿using System.Collections;

namespace IteratorsAndComparators
{
    public class Library : IEnumerable<Book>
    {
        private Book[] books;

        public Library(params Book[] books)
        {
            this.books = books; 
        }

        public IEnumerator<Book> GetEnumerator()
        {
            return new LibraryEnumerator(books);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }

    public class LibraryEnumerator : IEnumerator<Book>
    {
        private Book[] arr;
        private int index = -1;

        public LibraryEnumerator(Book[] arr)
        {
            this.arr = arr;
        }

        public Book Current => arr[index];

        object IEnumerator.Current => Current;

        public void Dispose()
        {

        }

        public bool MoveNext() => ++index < arr.Length;

        public void Reset()
        {

        }
    }
}
