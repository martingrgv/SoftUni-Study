﻿using MusicHub.Data;
using MusicHub.Data.Models;
using System.Reflection;

namespace MusicHub
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var assembly = AppDomain.CurrentDomain.GetAssemblies().Where(a => a.GetName() == "MusicHub.Data");
            var modelType = Assembly.GetExecutingAssembly().GetTypes().FirstOrDefault(t => t.Name == nameof(MusicHubDbContext));
        }
    }
}
