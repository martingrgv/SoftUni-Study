﻿using MusicHub.Data;
using MusicHub.Data.Models;
using System.Reflection;

namespace MusicHub
{
    public class StartUp
    {
        static void Main(string[] args)
        {
        }
    }
}
