﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        //public const string ConnectionString = @"Server=.;Database=CarDealer;Integrated Security=True;Encrypt=False";
        public const string ConnectionString = @"Server=.;Database=CarDealer;User Id=SA;Password=MasterDev24;";
    }
}
