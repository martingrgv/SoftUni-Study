﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=InvoicesExamDB;User Id=SA; Password=MasterDev24";
    }
}
