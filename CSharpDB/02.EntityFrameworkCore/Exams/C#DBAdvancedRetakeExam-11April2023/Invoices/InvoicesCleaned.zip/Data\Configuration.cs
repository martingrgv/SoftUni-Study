﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=InvoicesExamDB;Integrated Security=True";
    }
}
