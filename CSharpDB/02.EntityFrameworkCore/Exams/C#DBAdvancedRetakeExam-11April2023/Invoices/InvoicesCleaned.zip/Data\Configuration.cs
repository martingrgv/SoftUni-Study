﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost;Database=InvoiceDB;User Id=SA;Password=MasterDev1";
    }
}
