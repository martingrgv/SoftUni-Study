namespace Invoices.Data.Enumerations
{
    public enum CurrencyType
    {
        BGN,
        EUR,
        USD
    }
}
