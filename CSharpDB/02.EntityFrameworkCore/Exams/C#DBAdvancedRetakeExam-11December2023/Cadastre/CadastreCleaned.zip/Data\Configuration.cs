﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=localhost; Database=CSharpDBRetakeExam; Integrated Security=True;";
    }
}
