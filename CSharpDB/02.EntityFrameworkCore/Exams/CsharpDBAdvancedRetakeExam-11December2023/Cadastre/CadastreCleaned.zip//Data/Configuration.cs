﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=localhost; Database=CSharpDBRetakeExam; User Id=SA; Password=MasterDev24";
    }
}
