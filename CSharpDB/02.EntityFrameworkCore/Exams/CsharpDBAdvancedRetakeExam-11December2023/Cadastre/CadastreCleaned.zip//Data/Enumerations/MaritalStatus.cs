namespace Cadastre.Data.Enumerations
{
    public enum MaritalStatus
    {
        Unmarried,
        Married,
        Divorced,
        Widowed
    }
}
