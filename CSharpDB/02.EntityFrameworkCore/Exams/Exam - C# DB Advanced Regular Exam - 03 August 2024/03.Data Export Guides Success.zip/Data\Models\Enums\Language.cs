﻿namespace TravelAgency.Data.Models.Enums
{
    public enum Language
    {
        English,
        German,
        French,
        Spanish,
        Russian
    }
}
