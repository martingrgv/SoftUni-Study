using System;
using NUnit.Framework;
using System.Linq;
using System.Collections.Generic;

namespace SocialMediaManager.Tests
{
    public class Tests
    {
        private InfluencerRepository repository;
        
        [SetUp]
        public void SetUp()
        {
            repository = new InfluencerRepository();
        }
        
        [Test]
        public void Influencer_Constructor_SetsDataCorrectly()
        {
            Influencer influencer = new Influencer("Ivancho", 20);

            Assert.AreEqual("Ivancho", influencer.Username);
            Assert.AreEqual(20, influencer.Followers);
        }

        [Test]
        public void InfluencerRepository_Constructor_SetsDataCorrectly()
        {
            Assert.IsTrue(repository.Influencers.Count == 0);
        }
    }
}