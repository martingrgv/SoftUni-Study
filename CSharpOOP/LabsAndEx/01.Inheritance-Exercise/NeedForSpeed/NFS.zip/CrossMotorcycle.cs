﻿namespace NeedForSpeed
{
    public class CrossMotorcycle : Motorcycle
    {
        public CrossMotorcycle(int hp, double fuel) : base(hp, fuel)
        {
            
        }
    }
}
