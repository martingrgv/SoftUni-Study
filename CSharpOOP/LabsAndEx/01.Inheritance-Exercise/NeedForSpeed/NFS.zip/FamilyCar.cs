﻿namespace NeedForSpeed
{
    public class FamilyCar : Car
    {
        public FamilyCar(int hp, double fuel) : base(hp, fuel)
        {
            
        }
    }
}
