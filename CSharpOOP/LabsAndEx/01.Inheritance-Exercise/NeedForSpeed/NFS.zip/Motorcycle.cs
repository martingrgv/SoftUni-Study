﻿namespace NeedForSpeed
{
    public class Motorcycle : Vehicle
    {
        public Motorcycle(int hp, double fuel) : base(hp, fuel)
        {
            
        }
    }
}
