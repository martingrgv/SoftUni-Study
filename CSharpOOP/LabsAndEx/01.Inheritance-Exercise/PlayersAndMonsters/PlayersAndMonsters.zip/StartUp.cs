﻿using System;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            BladeKnight bk = new BladeKnight("Martingrgv", 100);
            Console.WriteLine(bk.ToString());
        }
    }
}