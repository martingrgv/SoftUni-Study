﻿namespace PhoneManufactory.Interfaces;
public interface IWebBrowsable
{
	public void WebBrowse(string URL);
}

