﻿namespace Celebration.Interfaces
{
	public interface ILiving
	{
		public DateOnly Birthdate { get; }
	}
}

