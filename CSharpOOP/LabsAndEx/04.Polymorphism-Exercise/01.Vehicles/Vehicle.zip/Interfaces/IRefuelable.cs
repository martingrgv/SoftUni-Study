﻿namespace Vehicles.Interfaces
{
    public interface IRefuelable
    {
        public void Refuel(double fuelAmount);
    }
}
