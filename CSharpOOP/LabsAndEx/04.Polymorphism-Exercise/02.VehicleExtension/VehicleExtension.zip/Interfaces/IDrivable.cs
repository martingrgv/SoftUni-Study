﻿namespace Vehicles.Interfaces
{
    public interface IDrivable
    {
        public void Drive(double distance);
    }
}
