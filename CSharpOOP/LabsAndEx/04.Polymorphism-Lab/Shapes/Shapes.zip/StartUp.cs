﻿namespace Shapes;
public class StartUp
{
    static void Main(string[] args)
    {
        //Circle circle = new Circle(5);
        //Console.WriteLine(circle.Draw());

        //Console.WriteLine();

        //Rectangle rect = new Rectangle(2, 4);
        //Console.WriteLine(rect.Draw());
    }
}
